import 'caja/styles/author.jquery-ui.css!';
import 'caja/styles/jquery.fileupload-ui.css!';
import 'caja/styles/A2J_Author.css!';
