export default {
  guideId: '20',
  templateId: '2114',
  updatedAt: '2015-11-23T14:15:11.499Z',
  title: 'Landlord Nonpayment DIY Program',
  rootNode: {
    tag: 'a2j-template',
    state: {},
    children: [
      { tag: 'a2j-repeat-loop',
        children: [],
        state: {},
        id: 'citvkuuhz00003k6aaeghgt9v'
      },
      { tag: 'a2j-conditional',
        children: [],
        state: {},
        id: 'citvkuui300013k6a8n9329e9'
      }
    ]
  }
};
