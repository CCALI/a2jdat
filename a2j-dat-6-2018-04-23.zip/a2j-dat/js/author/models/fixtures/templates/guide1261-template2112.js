export default {
  guideId: '1261',
  templateId: '2112',
  updatedAt: '2015-11-23T14:15:11.499Z',
  title: 'Authorization for Medical Treatment of a Minor',
  rootNode: {
    tag: 'a2j-template',
    state: {},
    children: [
      { tag: 'a2j-repeat-loop',
        state: {}
      },
      { tag: 'a2j-rich-text',
        state: {
          userContent: 'User\'s last name <a2j-variable name="Client last name TE" />.'
        }
      },
      { tag: 'a2j-rich-text',
        state: {
          userContent: `<p><em>Lorem ipsum dolor sit amet, pri ad porro consul
            disputando. Mea tale admodum cu, soluta fuisset per ad. Te omittam
            noluisse consequat vel. Impetus appetere antiopam sit ut, at nec
            inani forensibus necessitatibus. Eu eum appetere facilisis reprimique,
            an sit ignota fierent invenire, duis denique sea an. Sit ceteros
            dolores inimicus ut, nec id tantas delenit phaedrum. Nullam prompta
            sit ne.</em></p>`
        }
      }
    ]
  }
};
