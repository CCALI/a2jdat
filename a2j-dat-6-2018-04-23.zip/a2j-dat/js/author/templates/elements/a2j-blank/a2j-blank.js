import Component from 'can/component/';
import template from './a2j-blank.stache!';

export default Component.extend({
  template,
  leakScope: false,
  tag: 'a2j-blank-template'
});
